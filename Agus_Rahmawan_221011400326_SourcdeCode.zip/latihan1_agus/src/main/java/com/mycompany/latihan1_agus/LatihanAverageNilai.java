/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.latihan1_agus;
import java.util.Scanner;
/**
 *
 * @author Kuro Neko
 */
public class LatihanAverageNilai {
    public static void main (String [] args) {
        Scanner input = new Scanner (System.in);
        String nim, nama, grade;
        double uts,uas, rata, nia, nih;

        System.out.println("Data : ");
        System.out.print("NIM : "); nim = input.next();
        System.out.print("Nama : "); nama = input.next();
        System.out.print("Nilai UTS : "); uts = input.nextDouble();
        System.out.print("Nilai UAS : "); uas = input.nextDouble();
        System.out.print("Nilai harian : "); nih = input.nextDouble();
        System.out.print("Nilai Absensi : "); nia = input.nextDouble();
        
        rata = (uts + uas + nia + nih) / 4;
        
        
        if (rata < 50)
            grade = "E";
        else if (rata < 60)
            grade = "D";
        else if (rata < 70)
            grade = "C";
        else if (rata < 80)
            grade = "B";
        else
            grade = "A";
        
        System.out.println("======================================================");
        System.out.println("NIM\t\tNama\tUTS\tUAS\tNIH\tNIA\tRata2\tGrade");
        System.out.println(nim + "\t" + nama + "\t" + uts + "\t" + uas + "\t" + nih + "\t" + nia + "\t" + rata + "\t" + grade);
        System.out.println("");
        System.out.println("");
    }
}
