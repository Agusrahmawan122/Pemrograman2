/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.latihan1_agus;

/**
 *
 * @author Kuro Neko
 */
public class Latihan1_agus {

    public static void main(String[] args) {
        System.out.println("Hello World!");
        System.out.println("Nama : Agus Rahmawan");
    }
}
